<?php

# ==== Check polygon id function ====

function checkPolyId(int $id)
{
	$ret = NULL;

	if( ($respId = QB::table('polygons')->where(
			'id',
			'=',
			$id
		)->first->id) !== NULL )
	{
		# Return id
		$ret = $respId;
	}
	else
		error( [ 'bad' ] );

	return $ret;
}
