<?php

# ==== Get path code html function ====

# Gets path input name html file

function getPathCodeHtml(string $dir, string $name)
{
	return getPathCode($dir, 'html', $name);
}
